import React from 'react'
import ReactDOM from 'react-dom/client'
import InvestmentAppReal from './InvestmentAppReal'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <InvestmentAppReal />
  </React.StrictMode>,
)
