# 📊 App de Investimentos - Dados Reais do Mercado Brasileiro

Aplicação React que exibe dados em tempo real do mercado financeiro brasileiro, incluindo Ibovespa, Dólar, ações e notícias.

## 🚀 Como fazer deploy no Vercel

### Opção 1: Deploy via Interface Web (MAIS FÁCIL)

1. Acesse [vercel.com](https://vercel.com)
2. Faça login com sua conta (GitHub, GitLab ou Bitbucket)
3. Clique em **"Add New"** → **"Project"**
4. Importe o repositório do GitHub onde você subiu este código
5. O Vercel detectará automaticamente que é um projeto Vite
6. Clique em **"Deploy"**
7. Aguarde alguns minutos e seu app estará no ar! 🎉

### Opção 2: Deploy via CLI

```bash
# 1. Instale o Vercel CLI
npm install -g vercel

# 2. Entre na pasta do projeto
cd investment-app-vercel

# 3. Faça login no Vercel
vercel login

# 4. Deploy!
vercel

# 5. Para deploy em produção
vercel --prod
```

## 📦 Para rodar localmente

```bash
# Instalar dependências
npm install

# Rodar em desenvolvimento
npm run dev

# Build para produção
npm run build

# Preview do build
npm run preview
```

## ⚙️ Estrutura do Projeto

```
investment-app-vercel/
├── src/
│   ├── InvestmentAppReal.jsx  # Componente principal
│   ├── main.jsx                # Ponto de entrada
│   └── index.css               # Estilos Tailwind
├── index.html                  # HTML base
├── package.json                # Dependências
├── vite.config.js             # Configuração Vite
├── tailwind.config.js         # Configuração Tailwind
├── postcss.config.js          # Configuração PostCSS
└── vercel.json                # Configuração Vercel

```

## 🔧 Tecnologias Utilizadas

- **React 18** - Biblioteca UI
- **Vite** - Build tool ultrarrápido
- **Tailwind CSS** - Estilização
- **Lucide React** - Ícones
- **Vercel** - Hospedagem

## 📡 APIs Utilizadas

- **Brapi.dev** - Cotações de ações e Ibovespa
- **AwesomeAPI** - Cotação do dólar
- **Brapi News** - Notícias do mercado

## ⚠️ Avisos Importantes

- Este app é apenas para fins educacionais
- Não constitui recomendação de investimento
- Os dados são fornecidos por APIs públicas e podem ter delay
- Sempre consulte um especialista antes de investir

## 🐛 Solução de Problemas

### Erro 404 no Vercel
- ✅ Verifique se você fez o deploy da **pasta completa** do projeto
- ✅ Certifique-se de que o `vercel.json` está configurado corretamente
- ✅ O projeto precisa da estrutura completa com `package.json`, não apenas o arquivo `.jsx`

### Erro de Build
- Execute `npm install` para instalar todas as dependências
- Execute `npm run build` localmente para testar o build antes do deploy

### APIs não carregam
- As APIs públicas podem ter rate limits
- Aguarde alguns segundos e clique em "Atualizar Dados"
- Verifique o console do navegador para erros específicos

## 📞 Suporte

Se tiver problemas com o deploy, verifique:
1. Se todas as dependências foram instaladas
2. Se o build local funciona (`npm run build`)
3. Os logs de deploy no painel do Vercel

## 📝 Licença

Este projeto é livre para uso educacional.
